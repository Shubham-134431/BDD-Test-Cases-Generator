// Safe wrapper to prevent extension crash when extension context is invalidated
function executeWithActiveRecordingGate(callback) {
  if (!chrome.runtime || !chrome.runtime.id) return;
  try {
    chrome.storage.local.get({ isRecording: true }, (result) => {
      if (chrome.runtime.lastError) return;
      if (result && result.isRecording) {
        callback();
      }
    });
  } catch (e) {
    console.log("Extension context check caught gracefully:", e);
  }
}

let lastLoggedStepText = "";
let lastLoggedTimestamp = 0;

function sendUniqueStepMessage(stepText) {
  if (!chrome.runtime || !chrome.runtime.id) return;

  const currentTime = Date.now();
  if (stepText === lastLoggedStepText && (currentTime - lastLoggedTimestamp < 600)) {
    return; 
  }
  lastLoggedStepText = stepText;
  lastLoggedTimestamp = currentTime;
  
  setTimeout(() => {
    try {
      if (chrome.runtime && chrome.runtime.id) {
        chrome.runtime.sendMessage({
          type: "RECORD_STEP",
          step: { text: stepText }
        });
      }
    } catch (err) {
      console.log("Message delivery failed due to dynamic context loss.");
    }
  }, 5);
}

// 1. UNIVERSAL HEALTHCARE & ECOM PATH INTERPRETER ENGINE
function getReadablePageName(url) {
  try {
    const parsedUrl = new URL(url);
    const pathname = parsedUrl.pathname.toLowerCase();
    
    // Enterprise HIS System Path Resolvers
    if (pathname.includes("/op-registration") || pathname.includes("/opd-registration")) {
      return "OP Registration View";
    }
    if (pathname.includes("/out-patient-billing") || pathname.includes("/billing")) {
      return "Out Patient Billing Screen";
    }
    if (pathname.includes("/patient-history") || pathname.includes("/history")) {
      return "Patient History Records Dashboard";
    }
    if (pathname.includes("/in-patients") || pathname.includes("/ipd")) {
      return "In-Patients Module View";
    }
    if (pathname.includes("/auth-callback") || pathname.includes("/callback")) {
      return "Auth Callback View";
    }
    
    // Legacy E-Commerce Fallbacks
    if (pathname.includes("/verify") || parsedUrl.search.includes("otp")) {
      return "OTP Verification Screen";
    }
    if (pathname.includes("/login")) {
      return "Login Page";
    }
    if (pathname.includes("/cart")) {
      return "Shopping Cart Screen";
    }

    // Dynamic Segment Fallback Extractor
    let segments = pathname.split('/').filter(Boolean);
    let segment = segments.pop();
    if (segment) {
      if (segment.length > 20) segment = segment.substring(0, 15);
      return segment.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) + " View";
    }
    return "Platform Dashboard Portal";
  } catch (e) {
    return "Application Interface View";
  }
}

// Track SPA structural changes natively
let lastUrl = location.href;
setInterval(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    executeWithActiveRecordingGate(() => {
      const cleanScreenName = getReadablePageName(location.href);
      sendUniqueStepMessage(`user navigates to the "${cleanScreenName}"`);
    });
  }
}, 500);

if (window.location.href && !window.location.href.startsWith("chrome://")) {
  executeWithActiveRecordingGate(() => {
    const cleanScreenName = getReadablePageName(window.location.href);
    sendUniqueStepMessage(`user is on the "${cleanScreenName}"`);
  });
}

// 2. Element Field Dynamic Label Capturer
function getCleanFieldName(element) {
  if (element.type === "password") return "Password";

  let rawName = element.placeholder || element.name || element.id || element.getAttribute("aria-label") || "";
  let siblingText = "";
  
  if (element.parentElement) {
    Array.from(element.parentElement.children).forEach(sib => {
      if (sib !== element && sib.innerText) siblingText += " " + sib.innerText;
    });
  }
  
  const contextCombine = (rawName + " " + siblingText + " " + (element.className || "")).toLowerCase().replace(/\n/g, " ");

  if (contextCombine.includes("mobile") || contextCombine.includes("phone") || element.type === "tel") {
    return "Mobile Number";
  }
  if (contextCombine.includes("email") || element.type === "email") {
    return "Email ID";
  }
  if (contextCombine.includes("max id") || contextCombine.includes("maxid")) {
    return "Max ID Input Box";
  }
  if (contextCombine.includes("first name")) {
    return "First Name Field";
  }
  if (contextCombine.includes("pin") || contextCombine.includes("pincode")) {
    return "Pincode Box";
  }

  return rawName.trim().length > 2 ? rawName.trim() : "Target Input";
}

document.addEventListener("change", (event) => {
  executeWithActiveRecordingGate(() => {
    const element = event.target;
    if (element.tagName === "INPUT" || element.tagName === "TEXTAREA") {
      if (element.value && element.value.trim().length > 1 && element.type !== "password") {
        const fieldName = getCleanFieldName(element);
        sendUniqueStepMessage(`user enters "${element.value.trim()}" under "${fieldName}" field`);
      }
    }
  });
}, true);

// 3. Robust Pointer Tracker
document.addEventListener("click", (event) => {
  executeWithActiveRecordingGate(() => {
    const targetElement = event.target;
    const clickableContainer = targetElement.closest("button, a, [role='button'], li, option, [class*='btn'], [class*='button']");
    let elementNode = clickableContainer ? clickableContainer : targetElement;
    
    let textLabel = elementNode.innerText || elementNode.value || elementNode.placeholder || "";
    
    if (!textLabel.trim() && elementNode.parentElement) {
      textLabel = elementNode.parentElement.innerText || "";
    }
    if (!textLabel.trim() && targetElement) {
      textLabel = targetElement.innerText || "";
    }

    if (typeof textLabel === "string") {
      textLabel = textLabel.trim().replace(/\n/g, " ");
    }

    if (textLabel && textLabel.length > 0 && textLabel.length < 60) {
      const cleanClickLabel = textLabel.trim().replace(/[*:+91]/g, "").trim();
      if (cleanClickLabel.length > 1) {
        sendUniqueStepMessage(`user clicks on "${cleanClickLabel}" button`);
      }
    }
  });
}, true);
