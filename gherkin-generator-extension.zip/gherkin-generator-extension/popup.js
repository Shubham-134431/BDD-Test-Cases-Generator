document.addEventListener("DOMContentLoaded", () => {
  // 1. Storage values restoration
  chrome.storage.local.get(["featureName", "scenarioTitle", "isRecording"], (result) => {
    if (result.featureName) document.getElementById("featureNameInput").value = result.featureName;
    if (result.scenarioTitle) document.getElementById("scenarioTitleInput").value = result.scenarioTitle;
    
    const isRecording = result.isRecording !== false; 
    updateStatusUI(isRecording);
  });

  loadGherkinSteps();

  // 2. Active sync tracking bounds
  document.getElementById("featureNameInput").addEventListener("input", (e) => {
    chrome.storage.local.set({ featureName: e.target.value });
  });

  document.getElementById("scenarioTitleInput").addEventListener("input", (e) => {
    chrome.storage.local.set({ scenarioTitle: e.target.value });
  });

  document.getElementById("startBtn").addEventListener("click", () => {
    chrome.storage.local.set({ isRecording: true }, () => updateStatusUI(true));
  });

  document.getElementById("stopBtn").addEventListener("click", () => {
    chrome.storage.local.set({ isRecording: false }, () => updateStatusUI(false));
  });
 
  // 3. Export Operations Engine
  document.getElementById("copyBtn").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "GET_STEPS" }, (steps) => {
      const feature = document.getElementById("featureNameInput").value.trim();
      const scenario = document.getElementById("scenarioTitleInput").value.trim();
      if (!steps || steps.length === 0) {
        alert("No live steps recorded yet to copy!");
        return;
      }
      let gherkinOutput = generateGherkinText(steps, feature, scenario);
      navigator.clipboard.writeText(gherkinOutput).then(() => {
        alert("Success! Formatted Gherkin scenarios copied to clipboard.");
      });
    });
  });

  document.getElementById("downloadBtn").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "GET_STEPS" }, (steps) => {
      const feature = document.getElementById("featureNameInput").value.trim();
      const scenario = document.getElementById("scenarioTitleInput").value.trim();
      if (!steps || steps.length === 0) {
        alert("No steps available to export!");
        return;
      }
      let gherkinOutput = generateGherkinText(steps, feature, scenario);
      const blob = new Blob([gherkinOutput], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = (scenario.toLowerCase().replace(/[^a-z0-9]/g, "_") || "feature") + ".feature";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  });
 
  document.getElementById("clearBtn").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "CLEAR_STEPS" }, () => {
      chrome.storage.local.set({ featureName: "Work Flow", scenarioTitle: "" });
      document.getElementById("featureNameInput").value = "Product Purchase Flow";
      document.getElementById("scenarioTitleInput").value = "login";
      document.getElementById("stepList").innerHTML = '<div style="font-size:11px;color:#777;font-style:italic;padding:5px;">No steps recorded yet!</div>';
    });
  });
});

function updateStatusUI(isRecording) {
  const statusText = document.getElementById("statusText");
  if (statusText) {
    statusText.innerText = isRecording ? "Recording" : "Paused / Stopped";
    statusText.className = isRecording ? "status-recording" : "status-paused";
  }
}

// 4. REAL-TIME PREVIEW ENGINE WITH DYNAMIC STEP BREAKERS
function loadGherkinSteps() {
  chrome.runtime.sendMessage({ type: "GET_STEPS" }, (steps) => {
    const listEl = document.getElementById("stepList");
    if (!listEl) return;
    listEl.innerHTML = "";
    
    if (!steps || steps.length === 0) {
      listEl.innerHTML = '<div style="font-size:11px;color:#777;font-style:italic;padding:5px;">No steps recorded yet!</div>';
      return;
    }
    
    let blockIndex = 1;
    let subSteps = [];
    
    for (let i = 0; i < steps.length; i++) {
      const stepText = steps[i].text || steps[i];
      const lowerText = stepText.toLowerCase();
      subSteps.push(stepText);
      
      let milestoneTarget = "";
      
      // Calculate dynamic redirect checkpoints using text analytics boundaries
      if (lowerText.includes("navigates to") || lowerText.includes("is on the")) {
        const extractScreenMatch = stepText.match(/"([^"]+)"/);
        if (extractScreenMatch && extractScreenMatch[1]) {
          milestoneTarget = `Then user should verify redirect validation state on "${extractScreenMatch[1]}" dashboard`;
        }
      } else if (i === steps.length - 1) {
        milestoneTarget = "Then the platform execution completes the workflow lifecycle sequence successfully";
      }
      
      if (milestoneTarget && subSteps.length > 1) {
        const headerDiv = document.createElement("div");
        headerDiv.innerHTML = `<span style="color:#007bff; font-weight:bold; font-size:11px; margin-top:6px; display:block;"># Test Case ${blockIndex}</span>`;
        listEl.appendChild(headerDiv);
        
        subSteps.forEach((sub, idx) => {
          const li = document.createElement("li");
          let prefix = "And ";
          if (idx === 0) {
            prefix = (sub.toLowerCase().includes("click") || sub.toLowerCase().includes("enter")) ? "When " : "Given ";
          }
          li.textContent = prefix + sub;
          listEl.appendChild(li);
        });

        const finalLi = document.createElement("li");
        finalLi.textContent = milestoneTarget;
        finalLi.style.color = "#28a745";
        finalLi.style.fontWeight = "bold";
        listEl.appendChild(finalLi);
        
        blockIndex++;
        subSteps = []; 
      }
    }
  });
}

// 5. PLAIN-TEXT GHERKIN EXPORTER WITH DISTINCT SCENARIO WRAPPERS
function generateGherkinText(steps, feature, scenario) {
  let gherkin = `Feature: ${feature || "Enterprise System Workflow Management"}\n\n`;
  let blockIndex = 1;
  let subSteps = [];
  
  for (let i = 0; i < steps.length; i++) {
    const stepText = steps[i].text || steps[i];
    const lowerText = stepText.toLowerCase();
    subSteps.push(stepText);
    
    let milestoneTarget = "";
    if (lowerText.includes("navigates to") || lowerText.includes("is on the")) {
      const extractScreenMatch = stepText.match(/"([^"]+)"/);
      if (extractScreenMatch && extractScreenMatch[1]) {
        milestoneTarget = `Then user should verify redirect validation state on "${extractScreenMatch[1]}" dashboard`;
      }
    } else if (i === steps.length - 1) {
      milestoneTarget = "Then the user redirests on the Distination Screen";
    }
    
    if (milestoneTarget && subSteps.length > 1) {
      gherkin += `  Scenario: Test Case ${blockIndex}\n`;
      
      subSteps.forEach((sub, idx) => {
        let keyword = "And";
        if (idx === 0) {
          keyword = (sub.toLowerCase().includes("click") || sub.toLowerCase().includes("enter")) ? "When" : "Given";
        }
        gherkin += `    ${keyword} ${sub}\n`;
      });
      
      gherkin += `    ${milestoneTarget}\n\n`;
      
      blockIndex++;
      subSteps = [];
    }
  }
  
  return gherkin.trim();
}
