let recordedSteps = [];

chrome.runtime.onInstalled.addListener(() => {
  recordedSteps = [];
  chrome.storage.local.set({ isRecording: true, featureName: "User Authentication", scenarioTitle: "login" });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Background channel received system event type:", message.type);

  if (message.type === "RECORD_STEP") {
    if (message.step && message.step.text) {
      recordedSteps.push({ text: message.step.text });
      console.log("Step saved inside background array state manager:", message.step.text);
    }
    return false;
  }

  if (message.type === "GET_STEPS") {
    sendResponse(recordedSteps);
    return true; 
  }

  if (message.type === "CLEAR_STEPS") {
    recordedSteps = [];
    sendResponse({ success: true });
    return true;
  }
});



